# Template Website Hotel with HTML, CSS, JAVASCRIPT

## Screenshots

![preview img](/preview.png)